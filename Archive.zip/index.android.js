'use strict';

var React = require('react-native');
var {AppRegistry, Navigator, StyleSheet,Text,View} = React;
import Example from './Example';

AppRegistry.registerComponent('Example', () => Example);
