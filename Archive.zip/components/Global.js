'use strict';

module.exports = {
    currentUser: null,
    gStyle: require('../lib/styles'),
};
