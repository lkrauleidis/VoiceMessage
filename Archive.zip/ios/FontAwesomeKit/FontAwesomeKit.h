#ifndef FontAwesomeKit

#define FontAwesomeKit

#import "FAKIcon.h"
#import "FAKFontAwesome.h"
#import "FAKFoundationIcons.h"
#import "FAKZocial.h"
#import "FAKIonIcons.h"
#import "FAKMaterial.h"
#import "FAKOcticons.h"

#endif
