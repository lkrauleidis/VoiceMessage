'use strict';

var React = require('react-native');
var {AppRegistry, Navigator, StyleSheet,Text,View} = React;
import Main from './main';

AppRegistry.registerComponent('hyvi', () => Main);
